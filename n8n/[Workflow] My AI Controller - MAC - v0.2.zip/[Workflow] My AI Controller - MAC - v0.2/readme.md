## Tự động gửi tin nhắn và nhận phản hồi trình chat GPT
**Ưu điểm:** Không tốn tiền API, có thể dùng miễn phí (vẫn nên nâng Plus), Upload file dễ dàng (cần Plus), Sử dụng nhiều tính năng mà API không có
**Nhược điểm:** Kém ổn định
**Phù hợp với:**  Phân tích tài liệu lớn, viết bài, tạo ảnh, tạo video...

## Yêu cầu
**n8n-nodes-puppeteer**: https://www.npmjs.com/package/n8n-nodes-puppeteer
**chmome**: Hệ thống sẽ khởi động chrome bằng cách gọi powershell: Start-Process 'chrome.exe' . Do đó nếu lệnh này ko chạy đc thì cần liên hệ mình để sửa lại: 0964965320